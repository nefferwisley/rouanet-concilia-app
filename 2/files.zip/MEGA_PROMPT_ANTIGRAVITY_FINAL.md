# MEGA PROMPT — RouanetConcilia: Conclusão e Validação

> Cole este prompt inteiro no Antigravity. Ele já inclui as travas de
> segurança necessárias, o escopo exato do que fazer, e a exigência de
> validação cruzada com o Roo Cline antes de considerar qualquer item
> concluído.

---

```
CONTEXTO OBRIGATÓRIO — leia antes de qualquer ação:

Antes de fazer QUALQUER alteração, leia o arquivo
CONTEXTO_PROJETO_ROUANETCONCILIA.md (deve estar na raiz ou me pergunte
onde encontrá-lo). Ele explica as 3 partes do projeto, o que já está
funcionando, e os riscos conhecidos. NÃO recrie, não "corrija" nem
reescreva do zero nada que já está descrito como funcionando nesse
arquivo — só trabalhe nos itens pendentes listados abaixo.

REGRAS DE SEGURANÇA — não negociáveis:

1. NUNCA rode `git push --force` sem antes me mostrar exatamente o que
   seria sobrescrito e esperar minha confirmação explícita.
2. NUNCA delete arquivos em lote (`del *`, `rm -rf`, etc.) sem listar
   antes exatamente quais arquivos seriam apagados e esperar
   confirmação.
3. NUNCA modifique, comente sobre o conteúdo, ou tente "corrigir" o
   arquivo creds.json ou qualquer arquivo .env — esses são credenciais
   e devem permanecer intocados, apenas referenciados por caminho.
4. NÃO mexa no app Streamlit já publicado
   (repositório rouanet-concilia-app, pasta local
   meu_sistema_rouanet) além do que está explicitamente listado na
   seção "ESCOPO" abaixo. Ele está funcionando em produção.
5. Antes de qualquer commit, rode `git status` e me mostre a lista de
   arquivos que serão commitados. Nunca commite creds.json, .env, ou
   qualquer arquivo de credencial.
6. Se em algum momento você não tiver certeza sobre um ID, URL, nome
   de arquivo ou credencial, PARE e pergunte — não invente nem
   assuma valores.

ESCOPO — o que fazer, nesta ordem:

## Tarefa 1 — Finalizar o deploy da API no Render

Repositório: rouanet-concilia-api (pasta local: C:\Users\kATE\Desktop\api)

1. No painel do Render.com, conecte o repositório rouanet-concilia-api
   como um novo Web Service.
2. Configure:
   - Runtime: Python 3
   - Build Command: pip install -r requirements.txt
   - Start Command: uvicorn main:app --host 0.0.0.0 --port $PORT
3. Configure as variáveis de ambiente (Environment Variables):
   - API_KEY: gere uma chave forte aleatória (não peça pra mim, gere
     uma string aleatória segura de pelo menos 32 caracteres)
   - GOOGLE_CREDS_JSON: PARE aqui e me pergunte o conteúdo — não tente
     ler ou copiar o creds.json sozinho, peça que eu cole esse valor
     manualmente no painel do Render (nunca em texto pra você)
   - CORS_ALLOWED_ORIGIN: pergunte-me a URL exata do painel HTML
     (GitHub Pages) antes de preencher
4. Depois do deploy, teste o endpoint /health (não precisa de chave) e
   me mostre o resultado.
5. Teste o endpoint /planilha com a API_KEY configurada e confirme que
   retorna dados reais (197 linhas esperadas). Se der erro, PARE e me
   mostre o erro exato antes de tentar "consertar" sozinho.

## Tarefa 2 — Integrar o painel HTML legado com a nova API

Repositório: rouanet-concilia (painel HTML antigo, público)

1. Localize no index.html os trechos que fazem fetch direto para
   googleapis.com com Authorization Bearer (o fluxo OAuth do usuário).
2. Substitua essas chamadas por fetch para a nova API
   (URL do Render + endpoints /planilha, /pdfs,
   /validar-comprovantes), usando o header X-API-Key.
3. Remova o array de dados mockados "realRows1961" e qualquer outro
   dado hardcoded de exemplo, substituindo pela chamada real à API.
4. NÃO delete nem reescreva o design visual/CSS existente — só troque
   a camada de obtenção de dados.
5. Depois de cada mudança, teste abrindo o HTML localmente no
   navegador antes de fazer commit.

## Tarefa 3 — Persistência de decisões (prioridade alta da auditoria anterior)

No app Streamlit (rouanet-concilia-app) — esta é a ÚNICA mudança
permitida nesse repositório neste momento:

1. Hoje, decisões de Aprovado/Rejeitado na tabela editável se perdem
   se a página recarregar. Implemente persistência salvando o estado
   num arquivo JSON dentro da pasta do projeto no Google Drive
   (mesma pasta "3. 1961"), lido e escrito automaticamente a cada
   mudança na tabela.
2. Teste localmente: aprove uma linha, recarregue a página, confirme
   que a decisão permanece.

VALIDAÇÃO OBRIGATÓRIA COM ROO CLINE:

Depois de completar CADA tarefa acima (não só no final de tudo), abra
o Roo Cline e peça para ele revisar o código alterado com o seguinte
pedido:

"Revise as mudanças que acabaram de ser feitas em [nome do arquivo].
Aponte: (1) qualquer credencial, chave ou token exposto em texto
puro no código; (2) qualquer lógica que possa falhar silenciosamente
sem mostrar erro ao usuário; (3) qualquer diferença entre o que foi
pedido e o que foi de fato implementado. Seja crítico, não apenas
confirme que está bom."

Só marque uma tarefa como concluída depois que o Roo Cline revisar e
você (Antigravity) tiver corrigido os apontamentos dele, se houver.

AO FINAL DE CADA TAREFA:

Pare e escreva um resumo curto do que foi feito, o que o Roo Cline
apontou na revisão, e aguarde confirmação antes de seguir para a
próxima tarefa. Não execute as 3 tarefas em sequência sem pausas.
```

---

## Checklist para você conferir de manhã

- [ ] Tarefa 1 (deploy API) — concluída e validada pelo Roo Cline?
- [ ] Tarefa 2 (integração HTML) — concluída e validada pelo Roo Cline?
- [ ] Tarefa 3 (persistência) — concluída e validada pelo Roo Cline?
- [ ] Nenhum `git push --force` foi feito sem sua autorização
- [ ] Nenhuma credencial (creds.json, .env, API_KEY) apareceu em texto no chat do Antigravity ou em commits
- [ ] O app Streamlit publicado continua funcionando (testar a URL ao vivo)
