# Contexto do Projeto — RouanetConcilia

## Visão geral
Sistema de conciliação financeira para o Projeto 1961 (Lei Rouanet/SALIC),
produzido por Circunstância Cinematográfica, controlado por Júlia Sousa
(PRONAC 20.7453). O objetivo é ler dados do Google Drive com fidelidade,
validar comprovantes em PDF contra uma planilha de conciliação, e permitir
aprovação/rejeição linha a linha, com exportação final.

## Componentes existentes (3 peças separadas hoje)

### 1. App Streamlit (rouanet-concilia-app) — JÁ PUBLICADO E FUNCIONANDO
- Repositório: github.com/nefferwisley/rouanet-concilia-app (privado)
- URL ao vivo: rouanet-concilia-app-kocv8rxwzgtkfimcmosnxx.streamlit.app
- Pasta local: C:\Users\kATE\Desktop\meu_sistema_rouanet
- Stack: Python + Streamlit + Google Drive API (Service Account, não OAuth)
- Funcionalidades: login por senha, leitura da planilha "2. Conciliação
  1961.xlsx" (ID: 1q52xZirlzYCqpQJ7ldYNG9wQrVodPuJc) com detecção
  automática de cabeçalho, validação em lote de comprovantes PDF (pasta
  "1. Pagamentos", ID: 1ydDeUQQzcTRk6QhJY_QIow1SfaJyL0Mj) casando pelo
  número de CONTROLE no nome do arquivo, dashboard com gráfico de pizza,
  tabela editável (Aprovar/Rejeitar/Justificar), exportação CSV e PDF,
  justificativa automática opcional via IA (Gemini).
- Credenciais: local via creds.json (Service Account), na nuvem via
  Streamlit Secrets (TOML), nunca expostas no código.

### 2. Painel HTML legado (rouanet-concilia) — EXISTE, NÃO INTEGRADO
- Repositório: github.com/nefferwisley/rouanet-concilia (público)
- Single-file HTML (~4553 linhas), com dados MOCKADOS
  (array "realRows1961" hardcoded) e autenticação via OAuth do usuário
  no navegador (token em localStorage — menos seguro que Service Account)
- Título interno: "RouanetConcilia — SaaS Multi-Projetos"
- NÃO usa a planilha real nem os PDFs reais ainda.

### 3. API REST (rouanet-concilia-api) — EM CONSTRUÇÃO, DEPLOY EM ANDAMENTO
- Repositório: github.com/nefferwisley/rouanet-concilia-api (privado)
- Pasta local: C:\Users\kATE\Desktop\api
- Objetivo: expor a MESMA lógica confiável do app Streamlit (engine.py)
  como endpoints REST, para que o painel HTML legado (item 2) possa
  consumir dados reais em vez de mockados, sem precisar de OAuth do
  usuário nem duplicar a lógica de leitura.
- Stack: FastAPI + a mesma lógica de leitura/validação do Streamlit
- Endpoints: GET /health, GET /planilha, GET /pdfs, POST /validar-comprovantes
- Autenticação: header X-API-Key (chave definida via variável de ambiente)
- Deploy: Render.com (grátis) — EM ANDAMENTO no momento, ainda não
  finalizado. Faltava conectar o repositório no Render e configurar as
  variáveis de ambiente (API_KEY, GOOGLE_CREDS_JSON, CORS_ALLOWED_ORIGIN).

## Objetivo de médio prazo
Unificar em UMA ferramenta só: usar o painel HTML (visual, já existe e é
bonito) como front-end, consumindo dados reais e validados via a API REST
(item 3), que por sua vez usa a mesma lógica já testada do app Streamlit
(item 1). O app Streamlit pode continuar existindo em paralelo como
interface administrativa alternativa, ou ser aposentado depois — decisão
ainda em aberto.

## Riscos/pendências conhecidas (auditoria já feita)
- Casamento PDF↔planilha por regex simples no nome do arquivo (pode gerar
  falso positivo se houver outros números no nome)
- Sem persistência real das decisões (Aprovado/Rejeitado) entre sessões —
  hoje só existe em memória (session_state do Streamlit); recarregar a
  página perde o progresso não exportado
- Extração de valor do PDF pega o maior valor em R$ encontrado no texto
  (pode errar se o comprovante tiver múltiplos valores: subtotal, taxa, total)
- Sem histórico/log de auditoria de quem aprovou o quê e quando

## Segurança — cuidados já estabelecidos
- creds.json e .env NUNCA devem ser commitados no Git (.gitignore já
  configurado nos dois repositórios Python)
- Uma chave de Service Account já foi exposta acidentalmente nesta
  conversa em algum momento anterior e foi revogada/substituída
- Senha de acesso ao Streamlit é simples (não é segurança real, só
  barreira básica) — documentado no próprio código
